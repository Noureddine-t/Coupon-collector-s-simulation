# Latex Beamer LMU

Vorlage für deutschsprachige Präsentationen mit den [LMU-Farben](https://www.lmu.de/de/die-lmu/struktur/zentrale-universitaetsverwaltung/kommunikation-und-presse/lmu-brand-guide/designgrundsaetze/farben/index.html).

## Lizenz

```
Beamer Presentation
LaTeX Template

This template has been downloaded from:
http://www.LaTeXTemplates.com

It has been edited for teaching purposes by Daniel Krähmer and Dr. Gerrit Bauer (LMU).

License:
CC BY-NC-SA 3.0 (http://creativecommons.org/licenses/by-nc-sa/3.0/)

Further changes by Florian Sagerer.
```
